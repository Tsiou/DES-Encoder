﻿Σε ένα σύστημα με dotnet core 2.1, cd στον φάκελο DesEncoder και dotnet run DesEncoder.

Αλλιώς, από το Executable, σε x64 linux cd στον φάκελο executable και ./DesEncoder